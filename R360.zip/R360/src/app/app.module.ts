import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AppLoginComponent } from './components/app-login/app-login.component';
import { StorageService } from './main/services/storage.service';
import { SignInComponent } from './main/components/sign-in/sign-in.component';
import { MessagesModule } from 'primeng/messages';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { TranslateModule, TranslateLoader, TranslateService, MissingTranslationHandler } from '@ngx-translate/core';
import { ButtonModule } from 'primeng/button';
import { CommonService } from './main/services/common.service';
import { HttpErrorHandler } from './main/services/http-error-handler.service';
import { CommonDataBindingService } from './main/services/common-data-binding.service';
import { CommonMessageTransferService } from './main/services/common-message-transfer.service';
import { LoaderService } from './main/services/loader.service';
import { RestApiService } from './main/services/rest-api.service';
import { MessageService } from 'primeng/api';
import { MenuModule } from 'primeng/menu';
import { MiTranslateLoaderService } from './main/services/mi-translate-loader.service';
import { MiMissingTranslationHandlerService } from './main/services/mi-missing-translation-handler.service';
import { LayoutComponent } from './main/components/layout/layout.component';
import { SideBarComponent } from './main/components/side-bar/side-bar.component';
import { DashboardComponent } from './main/components/dashboard/dashboard.component';
import { HeaderComponent } from './main/components/header/header.component';
import {SidebarModule} from 'primeng/sidebar';
import {PanelMenuModule} from 'primeng/panelmenu';
import { JwtInterceptor } from './main/helper/jwt.interceptor';
import { ErrorInterceptor } from './main/helper/error.interceptor';
// import {  RouterModule, Routes, Router } from '@angular/router';
@NgModule({
  declarations: [
    AppComponent,
    AppLoginComponent,
    SignInComponent,
    LayoutComponent,
    SideBarComponent,
    DashboardComponent,
    HeaderComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    MenuModule,
    FormsModule,
    MessagesModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule,
    ButtonModule,
    SidebarModule,PanelMenuModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useClass: MiTranslateLoaderService
      },
      missingTranslationHandler: {
        provide: MissingTranslationHandler,
        useClass: MiMissingTranslationHandlerService
      }
    }),
    // RouterModule.forChild(AppRoutingModule)
  ],
  providers: [
    MessageService,
    TranslateService,
    StorageService,
    CommonService,
    HttpErrorHandler,
    CommonDataBindingService,
    CommonMessageTransferService,
    LoaderService,
    RestApiService,
    { provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true },
    // { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
