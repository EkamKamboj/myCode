import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SignInComponent } from './main/components/sign-in/sign-in.component';
import { LayoutComponent } from './main/components/layout/layout.component';
import { DashboardComponent } from './main/components/dashboard/dashboard.component';
import { AuthGuard } from './main/helper/auth-guard.service';


const routes: Routes = [
  {
    path: '',
    pathMatch: 'full',
    redirectTo: '/signin'
  },
  {
    path: 'signin',
    pathMatch: 'full',
    component: SignInComponent
  },
  {
    path: 'home',
    component: LayoutComponent,
    canActivate: [AuthGuard],
   
    children: [
      {
        path: '',
        redirectTo: 'overview',
       // canDeactivate: [DeactivateGuard],
        pathMatch: 'full'
        
      },
      {
        path: 'overview',
        component: DashboardComponent,
        pathMatch: 'full'
      },]
    }
];

@NgModule({
  imports: [RouterModule.forRoot(routes,{ enableTracing: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
