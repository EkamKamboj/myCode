import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Message } from 'primeng/api';
import { StorageService } from '../../services/storage.service';
import { CommonService } from '../../services/common.service';
import { AppConfiguration } from '../../constants/app-configuration';
import { User } from '../../interface/user';

@Component({
    selector: 'sign-in',
    templateUrl: 'sign-in.component.html',
    styleUrls: ['sign-in.component.scss']
})
export class SignInComponent implements OnInit{
    message: Message[] = [];
    hidePassword = true;
  
    signInForm = new FormGroup({
      username: new FormControl(),
      password: new FormControl()
    });
  
    constructor(
      private formBuilder: FormBuilder,
      private router: Router,
      private storageService: StorageService,
      private userService: CommonService,
      
    ) { }
  
    ngOnInit() {
      // this.ifSignedIn();
      this.signInForm = this.formBuilder.group({
        userName: ['', [Validators.required]],
        password: ['', [Validators.required]],
      });
    }
  
    doSignIn() {
      const signInData = {
        'USER_NAME': this.signInForm.controls.userName.value.trim(),
        'PASSWORD': this.signInForm.controls.password.value.trim()
      };
      this.autheticateCall(signInData);
    }
    
    autheticateCall(data){
      this.userService.authenticate('login-page', data).subscribe(result => {
        console.log("result is= "+result.token);
        localStorage.setItem("token",result.token);
        sessionStorage.setItem("IS_LOGIN","true");
        setTimeout(()=>{

          this.signInApiCall(data.USER_NAME);
        },5000);
    });
  }
    signInApiCall(userName) {
      // debugger;
      this.userService.signIn('', userName).subscribe(result => {
        this.signInForm.reset();
        this.storageService.setItemInCookies(AppConfiguration.LOGGED_IN_NAME, result.data.FIRST_NAME);
         this.storageService.setItemInCookies(AppConfiguration.LOGGED_IN_EMP_ID, result.data.EMP_ID);
         this.storageService.setItemInCookies(AppConfiguration.LOGGED_IN_DEPT_ID, result.data.DEPT_ID);
        //eStorageService.IS_LOGIN=true;
        if (result.data !== null) {
          this.router.navigate(['home/overview']);
        }
      // } , (error) => {
      //   console.log(error.message);
      //   this.message.push({ severity: 'error', summary: 'Error', detail: 'UserID/Password Wrong Combination' });
      //   setTimeout(() => {
      //     this.message = [];
      //   }, 2000);
      });
    }
  
    ifSignedIn() {
      // if (this.storageService.getItemFromCookies(AppConfiguration.TOKEN_KEY)) {
      //   this.router.navigate(['admin']);
      // }
    }
  
    showHidePassword() {
      this.hidePassword = !this.hidePassword;
    }
}
