import { Component, OnInit } from '@angular/core';
import { MenuItem } from 'primeng/api';
import { style } from '@angular/animations';
import { StyleCompiler } from '@angular/compiler';
@Component({
    selector: 'side-bar',
    templateUrl: 'side-bar.component.html',
    styleUrls: ['side-bar.component.scss']
})
export class SideBarComponent implements OnInit {
    items: MenuItem[];
    visibleSidebar1:any=true;
    ngOnInit() {
        this.items = [
            // {label: 'New', icon: 'fa fa-plus', url: 'http://www.primefaces.org/primeng'},
            //     {label: 'Open', icon: 'fa fa-download', routerLink: ['/overview']},
                // { label: 'Recent Files', icon: 'fa fa-download', routerLink: ['/overview'], queryParams: { 'recent': 'true' } },
            // { styleClass: 'r360-icon', label: 'R360' },
            { icon: 'fa fa-tachometer', styleClass:"dashboard-icon", label: 'Dashboard' },
            { icon:"rmgview-icon", label: 'RMG View' },
            { icon: 'custom-icon-menu', label:'Dept View'},
            { icon: 'fa fa-th-large', styleClass:"dashboard-icon", label: 'Insights' },
            { icon: 'fa fa-pencil-square-o', styleClass:"dashboard-icon", label: 'Create New' },
            { icon: 'fa fa-users', styleClass:"dashboard-icon", label: 'HR View' },

            // { styleClass: 'rmgview-icon', label: 'RMG View' },
            // { styleClass: 'deptview-icon', label: 'Dept View' },
            // { styleClass: 'insight-icon', label: 'Insights' },
            // { styleClass: 'newdlv-icon', label: 'Create New' },
            // { styleClass: 'hrview-icon', label: 'HR View' },
        ]
    }
}
