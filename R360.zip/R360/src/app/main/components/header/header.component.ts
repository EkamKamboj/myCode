import { Component, Input, OnInit, OnChanges, SimpleChange } from '@angular/core';

@Component({
    selector: 'app-header',
    templateUrl: 'header.component.html',
    styleUrls: ['header.component.scss']
})
export class HeaderComponent implements OnInit,OnChanges{
    @Input() billability:any;

    constructor(){

    }
     
    ngOnInit()
    {

    }

    ngOnChanges(changes: {[propKey: string]: SimpleChange}){
        console.log('changes ',changes);

    }
}
