import { Injectable } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';

import { Observable, throwError } from 'rxjs';
import { ErrorDTO } from '../interface/error';
import { FieldErrorDTO } from '../interface/field-error';
import { ErrorResponseDTO } from '../interface/error-response';


import { CommonMessageTransferService } from '../services/common-message-transfer.service';
import { LoaderService } from './loader.service';
import { StorageService } from './storage.service';
import { CommonDataBindingService } from './common-data-binding.service';
import {MessageService} from 'primeng/api';
export type HandleError = <T> (identifier?: string, result?: T) => (error: HttpErrorResponse) => Observable<T>;
@Injectable()
export class HttpErrorHandler {
  constructor(private router: Router,
              private messageService: MessageService,
              private loaderService: LoaderService,
              private commonMsgTrasferService: CommonMessageTransferService,
              private storageService: StorageService,
              private commonDataService: CommonDataBindingService) { }
  createHandleError = () => <T>
    (identifier = 'unknown', result = {} as T) => this.handleError(identifier, result)

  /**
   * Returns a function that handles Http operation failures.
   * This error handler lets the app continue to run as if no error occurred.
   * @param identifier - name of the identifier that failed
   * @param result - optional value to return as the observable result
   */
  handleError<T>(identifier = 'unknown', result = {} as T) {
    return (error: HttpErrorResponse): Observable<T> => {
      console.log(error," error is in code");
      this.messageService.clear();
      this.loaderService.hide();
      if (error.status === 0) {
        this.messageService.add({
          severity: 'error',
          summary: this.commonDataService.getLabel('msg_server_unreachable'),
          detail: this.commonDataService.getLabel('msg_server_unreachable_detail')
        });
        return throwError(result);
      }

      if (error.status === 500) {
        this.parseFieldErrors(error, identifier, 500);
        return throwError(result);
      }

      if (error.status === 401) {
        this.messageService.add({
          severity: 'error',
          summary: 'an error has occured!',
          detail: error.error.message
        });
        // this.router.navigate(['/signin']);
        return throwError(result);
      }
      if (error.status === 409) {
        this.messageService.add({
          severity: 'info',
          summary: 'R360-App Info',
          detail: error.error.message
        });
        // this.router.navigate(['/signin']);
        return throwError(result);
      }

      if (error.status === 403) {
        this.messageService.clear();
        this.messageService.add({
          severity: 'error',
          summary: this.commonDataService.getLabel('msg_invalid_session'),
          detail: this.commonDataService.getLabel('msg_invalid_session_detail')
        });
        //this.storageService.setItemInCookies(AppSettings.TOKEN_KEY, '');
        setTimeout(() => {
          window.location.reload();
        }, 2000);
        //   this.router.navigate(['/signin']);
        return;
      }

      if (error.error.errors !== undefined && error.error.errors !== null) {
        if (error.status === 400) {
          // this.parseFieldErrors(error, identifier, 400);
          return throwError(result);
        }
      }
      return throwError(result);
    };
  }

  manageGeneralMsg(generalDto: ErrorDTO, code: number) {
    let errorHeader = 'Error';
    if (code === 500) {
      errorHeader = 'Server Error';
    }
    this.messageService.add({
      severity: 'error',
      summary: errorHeader,
      detail: generalDto.message
    });
    this.commonMsgTrasferService.throwGeneralError(generalDto);
  }

  parseFieldErrors(error: HttpErrorResponse, identifier: string, code: number) {
    const fieldResponse: FieldErrorDTO[] = [];
    console.log("error ****** ",error)
    const keys = Object.keys(error.error.errors);
    let isGeneralError = false;
    keys.forEach(key => {
      console.log('Key found :', key);
      if (isGeneralError) {
        return;
      }
      const filedErrors: ErrorDTO[] = error.error.errors[key];
      if (key === 'general') {
        isGeneralError = true;
        filedErrors[0].identifier = identifier;
        this.manageGeneralMsg(filedErrors[0], code);
        return;
      }
      const dto: FieldErrorDTO = new FieldErrorDTO();
      dto.fieldName = key;
      dto.fielsErrors = filedErrors;
      fieldResponse.push(dto);
    });
    if (isGeneralError) {
      return;
    }
    const errorResponse: ErrorResponseDTO = new ErrorResponseDTO();
    errorResponse.fielsErrors = fieldResponse;
    errorResponse.identifier = identifier;
    this.commonMsgTrasferService.throwFieldsError(errorResponse);
  }
}
