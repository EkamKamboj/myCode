import { Injectable } from '@angular/core';
import { TranslateLoader } from '@ngx-translate/core';
import { of, Observable } from 'rxjs';

@Injectable()
export class MiTranslateLoaderService implements TranslateLoader {

  getTranslation(lang: string): Observable<any> {
    return of({
      DLV_NUMBER: 'DLV No.',
      PROJECT_NAME_AS_PER_RMG: 'Project',
      VALID_TO: 'DLV Valid Until',
      DLVEMPLOYEES: '#DLV Employees',
      ACTUALEMPLOYEE: '#Actual Employees',
      CURRENCY: 'Currency',
      EMP_ID: 'Employee Id',
      EMPNAME: 'Employee Name',
      DEPARTMENT: 'Department',
      ROLE: 'Designation',
      TECHNOLOGY_CLUSTER: 'Technology cluster',
      LEVEL: 'Level'
    });
  }
}
