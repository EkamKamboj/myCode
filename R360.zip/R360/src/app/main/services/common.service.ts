import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { RestApiService } from './rest-api.service';

@Injectable()
export class CommonService {
  getUserData(d,user: string) {
    return this.restApiService.get(d,'/userDetail?userName='+user);
  }

  constructor(private restApiService: RestApiService) { }
  // signOut(): Observable<any> {
  //   return this.restApiService.delete('/secure/signout', 'page-center');
  // }

  
  authenticate(d, data): Observable<any> {
    return this.restApiService.post(d, '/authenticate', data, 'page-center');
  }
  signIn(d, data): Observable<any> {
    return this.restApiService.get(d, '/userDetail?userName='+data, 'page-center');
  }

  createUser(d, data): Observable<any> {
    return this.restApiService.post(d, '/createUser', data, 'page-center');
  }
  createEmployee(d, data): Observable<any> {
    return this.restApiService.post(d, '/createEmployee', data, 'page-center');
  }
  createDLV(d, data): Observable<any> {
    return this.restApiService.post(d, '/createDLV', data, 'page-center');
  }

  resetPassword(d, data): Observable<any> {
    return this.restApiService.post(d, '/updatepassword', data, 'page-center');
  }

  signOut(): Observable<any> {
    return this.restApiService.get('header', '/logout', 'page-center');
  }

  getUserProfile(): Observable<any> {
    return this.restApiService.get('profile', '/secure/users/profile', 'page-center');
  }
}

