import { Injectable, NgZone, EventEmitter } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AppConfiguration } from '../constants/app-configuration';
import { StorageService } from './storage.service';
import { catchError, map, tap } from 'rxjs/operators';

import { LoaderService } from './loader.service';
import { HttpErrorHandler, HandleError } from './http-error-handler.service';

@Injectable()
export class RestApiService {
  httpHandleError: HandleError;
  constructor(private httpClient: HttpClient, private httpErrorHandler: HttpErrorHandler,
    private storageService: StorageService, private loaderService: LoaderService) {
    this.httpHandleError = this.httpErrorHandler.createHandleError();
  }

  private prependApiUrl(url: string): string {
    url =  AppConfiguration.BASE_URL + url;
    console.log("usrl is ******* ",url);
    return url;
  }

  get(identifier: string, url: string, loader?: string) : Observable<any> {
    this.showLoader(loader);
    return this.handleHttpSuccess(this.callerWithoutBody('get', identifier, url));
  }

  postDataInString(identifier: string, url: string,  body: any, loader?: string): Observable<{}> {
    this.showLoader(loader);
    // const head = { headers: this.getHttpClientHeaders(), , withCredentials: true };
     return this.httpClient.post(this.prependApiUrl(url), body, {responseType:'text'}).pipe(
      tap(data => {
        return data;
      })
    );
    // return this.handleHttpSuccess(this.callerWithoutBody('get', identifier, url));
  }

  post(identifier: string, url: string, body: any, loader?: string): Observable<{}> {
    this.showLoader(loader);
    return this.handleHttpSuccess(this.callerWithBody('post', identifier, url, body));
  }

  postFile(identifier: string, url: string, body: any, loader?: string): Observable<{}> {
    this.showLoader(loader);
    return this.handleHttpSuccess(this.callerWithBody('post-file', identifier, url, body));
  }

  put(identifier: string, url: string, body?: any, loader?: string): Observable<{}> {
    this.showLoader(loader);
    return this.handleHttpSuccess(this.callerWithBody('put', identifier, url, body));
  }

  patch(identifier: string, url: string, body?: any, loader?: string): Observable<{}> {
    this.showLoader(loader);
    return this.handleHttpSuccess(this.callerWithBody('patch', identifier, url, body));
  }

  delete(identifier: string, url: string, loader?: string): Observable<{}> {
    return this.handleHttpSuccess(this.callerWithoutBody('delete', identifier, url));
  }

  callerWithoutBody(method: string, identifier: string, url: string): Observable<{}> {
    console.log("comes here ",method," and url ",url);
    const head = { headers: this.getHttpClientHeaders(), withCredentials: true };
    const that = this;
    if (method === 'get') {
      console.log("comes here ",method," and url ",url);
      return this.httpClient.get(this.prependApiUrl(url), head).pipe(
        // catchError(this.httpHandleError(identifier, []))
        tap(data => console.log("tap data is ",data))
      ).pipe(
        map((r: Response) => {
          that.hideLoader();
          return r;
        })
      );
    } else if (method === 'delete') {
      return this.httpClient.delete(this.prependApiUrl(url), head).pipe(
        catchError(this.httpHandleError(identifier, []))
      ).pipe(
        map((r: Response) => {
          that.hideLoader();
          return r;
        })
      );
    }
  }

  callerWithBody(method: string, identifier: string, url: string, body?: any): Observable<{}> {
    const that = this;
    const head = { headers: this.getHttpClientHeaders(), withCredentials: true };
    const headForFileUpload = { headers: this.getHttpClientHeadersForFileUpload(), withCredentials: true };
    if (method === 'put') {
      return this.httpClient.put(this.prependApiUrl(url), body, head).pipe(
        catchError(this.httpHandleError(identifier, []))
      ).pipe(
        map((r: Response) => {
          that.hideLoader();
          return r;
        })
      );
    } else if (method === 'post') {
      return this.httpClient.post(this.prependApiUrl(url), body, head).pipe(
        catchError(this.httpHandleError(identifier, []))
      ).pipe(
        map((r: Response) => {
          that.hideLoader();
          return r;
        })
      );
    } else if (method === 'patch') {
      return this.httpClient.patch(this.prependApiUrl(url), body, head).pipe(
        catchError(this.httpHandleError(identifier, []))
      ).pipe(
        map((r: Response) => {
          that.hideLoader();
          return r;
        })
      );
    }
  }

  image(identifier: string, url: string, fileName: string, loader?: string) {
    // responseType: ResponseContentType.Blob
    this.showLoader(loader);
    const head = { headers: this.getHttpClientHeaders() };
    const res = this.httpClient.get(url, head).pipe(
      catchError(this.httpHandleError(identifier, []))
    );
    this.downloadFile(res, this.getContentType(fileName), fileName);
  }

  private getHttpClientHeaders(): HttpHeaders {
    if (this.storageService.getItemFromCookies(AppConfiguration.TOKEN_KEY) !== undefined
      && this.storageService.getItemFromCookies(AppConfiguration.TOKEN_KEY) !== null
      && this.storageService.getItemFromCookies(AppConfiguration.TOKEN_KEY).length > 0) {
      return new HttpHeaders({
        'Accept-Language': AppConfiguration.HEADER_ACCEPT_LANGUAGE,
        // 'Content-Type': AppConfiguration.HEADER_CONTENT_TYPE,
        'Accept': AppConfiguration.HEADER_CONTENT_TYPE,
        'x-access-token': this.storageService.getItemFromCookies(AppConfiguration.TOKEN_KEY)
      });
    }
    return new HttpHeaders({
      'Accept-Language': AppConfiguration.HEADER_ACCEPT_LANGUAGE,
      // 'Content-Type': AppConfiguration.HEADER_CONTENT_TYPE,
      'Accept': AppConfiguration.HEADER_CONTENT_TYPE,
      'Access-Control-Allow-Credentials':'true'
    });
  }

  private getHttpClientHeadersForFileUpload(): HttpHeaders {
    return new HttpHeaders({
      'Accept-Language': AppConfiguration.HEADER_ACCEPT_LANGUAGE,
      'Content-Type': 'multipart/form-data',
      'Accept': AppConfiguration.HEADER_CONTENT_TYPE,
      'x-access-token': this.storageService.getItemFromCookies(AppConfiguration.TOKEN_KEY)
    });
  }

  private handleHttpSuccess(res: Observable<{}>): Observable<{}> {
    // debugger;
    return res;
  }

  downloadFile(data: any, contentType: string, fileName: string) {
    const blob = new Blob([data], { type: contentType });
    const link = document.createElement('a');
    link.href = window.URL.createObjectURL(blob);
    link.download = fileName;
    link.click();
    this.hideLoader();
    // setTimeout(link.remove(), 1000);
  }

  public getContentType(type: string) {
    const extension = type.substring(type.lastIndexOf('.') + 1).toLowerCase();
    switch (extension) {
      case 'jpeg':
        return 'image/jpeg';
      case 'jpg':
        return 'image/jpeg';
      case 'png':
        return 'image/png';
      case 'gif':
        return 'image/gif';
      case 'bmp':
        return 'image/x-ms-bmp';
      case 'pdf':
        return 'application/pdf';
      case 'xls':
        return 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
    }
    return '';
  }

  private onEnd(): void {
    this.hideLoader();
  }

  private showLoader(loader?: string): void {
    if (loader !== undefined && loader !== null && 'none' !== loader.toLowerCase()) {
      this.loaderService.show(loader);
    }
  }

  private hideLoader(): void {
    this.loaderService.hide();
  }
}
