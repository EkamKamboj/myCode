import { Injectable, EventEmitter } from '@angular/core';
import { Subject } from 'rxjs';
import { ErrorDTO } from '../interface/error';
import { ErrorResponseDTO } from '../interface/error-response';

@Injectable()
export class CommonMessageTransferService {

  private _restAPIFieldErrorEvent = new EventEmitter<ErrorResponseDTO>();
  private _restAPIGeneralErrorEvent = new EventEmitter<ErrorDTO>();

  constructor() { }

  get restAPIGeneralErrorEvent(): EventEmitter<ErrorDTO> {
    return this._restAPIGeneralErrorEvent;
  }
  get restAPIFieldErrorEvent(): EventEmitter<ErrorResponseDTO> {
    return this._restAPIFieldErrorEvent;
  }
  throwFieldsError(errors: ErrorResponseDTO) {
    this._restAPIFieldErrorEvent.emit(errors);
  }

  throwGeneralError(error: ErrorDTO) {
    this._restAPIGeneralErrorEvent.emit(error);
  }
}
