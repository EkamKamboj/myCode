export class ErrorDTO {
    identifier: string;
    messageCode: string;
    message: string;
  }