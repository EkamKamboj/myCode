import { FieldErrorDTO } from './field-error';
export class ErrorResponseDTO {
  identifier: string;
  fielsErrors: FieldErrorDTO[];
}
