import { ErrorDTO } from './error';
export class FieldErrorDTO {
  fieldName: string;
  fielsErrors: ErrorDTO[];
}
