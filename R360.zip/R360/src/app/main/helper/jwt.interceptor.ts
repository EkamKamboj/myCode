import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor } from '@angular/common/http';
import { Observable } from 'rxjs';
import { StorageService } from '../services/storage.service';
import { AppConfiguration } from '../constants/app-configuration';
import { type } from 'os';


@Injectable()
export class JwtInterceptor implements HttpInterceptor {
    constructor(private storageService: StorageService) {
        console.log("constrrrrrrrrrrrrrrr");
    }

    intercept(req: HttpRequest<any>,
        next: HttpHandler): Observable<HttpEvent<any>> {

        const idToken = localStorage.getItem("token");
        console.log(idToken,"localStorage.getItem *** ",localStorage.getItem("token"));

        if(req.headers.get('notoken') !== 'noToken' && idToken) {
            req = req.clone({
                setHeaders: {
                    Authorization: "Bearer "+idToken,
                    "Content-Type":"text/plain"
                }
            });
            console.log("getItem *** ",req.headers.get("Authorization"));
            return next.handle(req);

        }
        else {
            return next.handle(req);
        }
    }
    // intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    //     // add authorization header with jwt token if available
    //     let currentUser = this.storageService.getItemFromCookies(AppConfiguration.LOGGED_IN_NAME);
    //     let token = localStorage.getItem("token");
    //     console.log("currentUser ",currentUser," and token ",token);
    //     if ( token) {
    //         let abc= 'Bearer ${token}'
    //         console.log('Bearer ${token}');

    //         request = request.clone({
    //             setHeaders: {
    //                 Authorization: `Bearer `+token
    //             }
    //         });
    //         console.log("headers *********** ",request.headers);
    //     }
    // else
    // {
    //     request = request.clone({
    //         setHeaders: {
    //             'Access-Control-Allow-Credentials':'true'
    //         }
    //     }); 
    // }

    // return next.handle(request);
    // }
}